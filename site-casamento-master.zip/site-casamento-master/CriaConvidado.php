<?php
    require_once("class/Convidado.php");

    $convidado = new Convidado();

    
