<?php

class Presente {

    public $id;
    public $titulo;
    public $valor;
    public $link;
    public $imagem;
    public $categoria;
    public $categoriaId;
}
