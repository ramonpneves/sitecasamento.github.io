<?php

class Convidado {

    public $id;
    public $nome;
    public $confirmacao;
    public $email;
    public $telefone;
    public $categoria;
}
